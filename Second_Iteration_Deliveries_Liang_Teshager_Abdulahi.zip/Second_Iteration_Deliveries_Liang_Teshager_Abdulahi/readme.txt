
Assignment Type: Second Iteration Deliveries readme.txt

Team names: Weilan Liang, Dereje Teshager, and Aden Abdulahi

The team started working second iteration deliveries from February 10, 2025, to February 16, 2025.
We had conducted two meetings, and we created sprint/Iteration 2. In sprint 2 we spent a total
time of 26 hours.

The challenge: 1. On sprint 2 we had confusion on how to do UML relationships
    between classes.
    2. Code writing like putting data from the SQL to tkinter frame.
    3. How to handle database.
Solution: 1. We received a comment from professor Tom, and we consulted and received feedback,
    and clarification.
    2. code writing, weilan consulted professor Tom and advised to use observer to notify, GUI class
    to update data. Additionally, as we are in the draft phase we will consult professor Tom,
    if we encounter/face coding challenges.
    3. recreating database_manager class to manipulate data into the database.


