
Assignment Type: Fifth Iteration Deliveries readme.txt

Team names: Weilan Liang, Dereje Teshager, and Aden Abdulahi

The team started working Fifth iteration deliveries from March 3, 2025, to March 9, 2025.
We had conducted two meetings, and we created sprint/Iteration five. In sprint five we spent a total
time of  29 hours.

The challenge: 1. Creating csv file, and sending and email attached with the watched data.
               2. Converting the file watch program in to MVC, during this the challenge was
                    a) How to call controller on GUI(VIEW)
                    b) How to correctly implement MVC to all classes
               3. How to query between times?

Solution:
    1. To create csv file, and send that as an attachment with email, a representative of the
    team spoke to the instructor and received guidance and the team implemented
    a working code accordingly.

    2. Read PowerPoint class slides, researched online like Google, YouTube, documentation
        a) Setting controller to None, then set view.controller = controller,
            then view.model = model, on script.
        b) Filewatch class inherits from controller, while databasemanager inherits from model,
           and Tkinter inherits from view.
    3. How to query between times? This issue still remains unsolved and we plan will to discuss
       this with professor on how to implement and query between times.