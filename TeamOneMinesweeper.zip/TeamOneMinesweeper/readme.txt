Student Names: Aden Abdulahi, Weilan Liang, Dereje Teshager
Course: TCSS 404
Group Assignment 1: Team Solution to minesweeper problem
Started date: January 20, 2025
Finished date: January 23, 2025
Aden Abdulahi spent working this group assignment a total of 4 hours
Weilan Liang spent working this group assignment a total of 6 hours ++
Dereje Teshager spent working this group assignment a total of 4 hours ++
Total hours spent: 14 hours

We had 2 number of group meeting/s and established our GitHub remote repository for easy
access of group work and documentation. Additionally we have written our onw bylaw and agreed
 on it.


